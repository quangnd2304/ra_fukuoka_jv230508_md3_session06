create
    definer = root@localhost procedure get_product_by_id(IN productid_in int)
BEGIN
	select *
    from product
    where productid = productid_in;
END;

