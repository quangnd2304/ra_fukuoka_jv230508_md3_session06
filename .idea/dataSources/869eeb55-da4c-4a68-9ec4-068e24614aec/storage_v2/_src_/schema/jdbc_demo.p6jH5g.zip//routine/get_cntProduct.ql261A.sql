create
    definer = root@localhost procedure get_cntProduct(IN fromPrice float, IN toPrice float, OUT cnt int)
BEGIN
	select count(p.productid) into cnt
    from product p
    where p.price between fromPrice and toPrice;
END;

