create
    definer = root@localhost procedure update_product(IN productid_in int, IN productname_in varchar(100),
                                                      IN price_in float, IN productstatus_in bit)
BEGIN
	update product
    set productname = productname_in,
		price = price_in,
        productstatus = productstatus_in
	where productid = productid_in;
END;

