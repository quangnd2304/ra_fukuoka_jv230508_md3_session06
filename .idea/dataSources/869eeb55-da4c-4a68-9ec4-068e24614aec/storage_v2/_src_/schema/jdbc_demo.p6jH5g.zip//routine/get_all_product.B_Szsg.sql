create
    definer = root@localhost procedure get_all_product()
BEGIN
	select * from product;
END;

