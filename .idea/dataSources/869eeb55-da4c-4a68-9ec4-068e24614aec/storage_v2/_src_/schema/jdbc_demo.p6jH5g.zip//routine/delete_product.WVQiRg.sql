create
    definer = root@localhost procedure delete_product(IN productid_in int)
BEGIN
	delete from product
    where productid = productid_in;
END;

