create
    definer = root@localhost procedure create_product(IN productname_in varchar(100), IN price_in float,
                                                      IN productstatus_in bit)
BEGIN
	insert into product(productname,price,productstatus)
    values(productname_in,price_in,productstatus_in);
END;

